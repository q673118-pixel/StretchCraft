# StretchCraft — Minecraft Java 26.3 / Fabric

Client-side prototype for stretched 3D projection with aspect presets (4:3, 16:10, 5:4, 16:9, 21:9, 32:9 and custom ratio).

## Controls
- `Right Shift + R`: open the configuration screen.
- In the menu, cycle through presets, toggle the effect, or enter custom width/height values.
- Config file: `.minecraft/config/stretchcraft.json`.

## Important compatibility note
This source targets Minecraft 26.3, Fabric Loader 0.19.5, Fabric API 0.162.0+26.3, Loom 1.17 and Java 25. The Minecraft 26.3 rendering and GUI APIs are recent and the source has not been compiled or run in an actual M.J. Launcher environment here. If the build reports a mapping/signature error, the mixin target or a GUI API name may need adjustment against the exact 26.3 client jar. This is source code, not a prebuilt, verified JAR.

## Build
1. Install a JDK 25 and Gradle 9.6.0 (or a compatible Gradle 9.6+ release).
2. Open this project in a Gradle-capable IDE, or run in the project directory:
   - Linux/macOS/Termux: `gradle build`
   - Windows: `gradle.bat build`
3. The output JAR should be in `build/libs/`.
4. Copy the resulting `stretchcraft-1.0.0.jar` into the Minecraft instance's `mods` folder used by M.J. Launcher. Make sure that same instance uses Minecraft 26.3 and Fabric Loader 0.19.5 or newer.

## Android notes
The mod is client-side and does not require a separate server installation. Building on Android is possible if the environment has a working JDK 25 and Gradle; many Android Java IDEs/launchers do not bundle these exact tool versions, so building on a PC and transferring the JAR may be easier. The mod itself does not bundle Fabric Loader or Fabric API.
