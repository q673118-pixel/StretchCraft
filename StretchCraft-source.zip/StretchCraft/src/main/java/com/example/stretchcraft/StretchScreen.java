package com.example.stretchcraft;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

public final class StretchScreen extends Screen {
    private EditBox widthBox;
    private EditBox heightBox;

    public StretchScreen() { super(Component.literal("StretchCraft")); }

    @Override
    protected void init() {
        int cx = this.width / 2;
        int y = this.height / 4;
        addRenderableWidget(Button.builder(Component.literal("Формат: " + StretchConfig.PRESETS[StretchConfig.preset]), b -> {
            StretchConfig.nextPreset(); b.setMessage(Component.literal("Формат: " + StretchConfig.PRESETS[StretchConfig.preset]));
        }).bounds(cx - 100, y, 200, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Растягивание: " + (StretchConfig.enabled ? "ВКЛ" : "ВЫКЛ")), b -> {
            StretchConfig.enabled = !StretchConfig.enabled; StretchConfig.save(); b.setMessage(Component.literal("Растягивание: " + (StretchConfig.enabled ? "ВКЛ" : "ВЫКЛ")));
        }).bounds(cx - 100, y + 26, 200, 20).build());
        widthBox = new EditBox(this.font, cx - 100, y + 58, 95, 20, Component.literal("Ширина"));
        widthBox.setValue(Double.toString(StretchConfig.customWidth));
        widthBox.setMaxLength(8);
        addRenderableWidget(widthBox);
        heightBox = new EditBox(this.font, cx + 5, y + 58, 95, 20, Component.literal("Высота"));
        heightBox.setValue(Double.toString(StretchConfig.customHeight));
        heightBox.setMaxLength(8);
        addRenderableWidget(heightBox);
        addRenderableWidget(Button.builder(Component.literal("Сохранить свои пропорции"), b -> saveCustom())
                .bounds(cx - 100, y + 84, 200, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Готово"), b -> { StretchConfig.save(); onClose(); })
                .bounds(cx - 100, y + 112, 200, 20).build());
    }

    private void saveCustom() {
        try {
            StretchConfig.customWidth = Math.max(0.25, Math.min(32.0, Double.parseDouble(widthBox.getValue().trim())));
            StretchConfig.customHeight = Math.max(0.25, Math.min(32.0, Double.parseDouble(heightBox.getValue().trim())));
            StretchConfig.preset = 6;
            StretchConfig.save();
        } catch (NumberFormatException ignored) { }
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        renderBackground(graphics, mouseX, mouseY, partialTick);
        graphics.drawCenteredString(this.font, this.title, this.width / 2, this.height / 4 - 24, 0xFFFFFF);
        graphics.drawCenteredString(this.font, "Открыть меню: Right Shift + R", this.width / 2, this.height - 28, 0xAAAAAA);
        super.render(graphics, mouseX, mouseY, partialTick);
    }

    @Override public boolean isPauseScreen() { return false; }
}
