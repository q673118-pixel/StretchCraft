package com.example.stretchcraft;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

public final class StretchConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("stretchcraft.json");
    public static final String[] PRESETS = {"4:3", "16:10", "5:4", "16:9", "21:9", "32:9", "Custom"};
    public static int preset = 3;
    public static double customWidth = 4.0;
    public static double customHeight = 3.0;
    public static boolean enabled = true;

    private StretchConfig() {}

    public static double targetAspect() {
        if (preset == 6) return Math.max(0.25, Math.min(8.0, customWidth / Math.max(0.25, customHeight)));
        return switch (preset) {
            case 0 -> 4.0 / 3.0;
            case 1 -> 16.0 / 10.0;
            case 2 -> 5.0 / 4.0;
            case 4 -> 21.0 / 9.0;
            case 5 -> 32.0 / 9.0;
            default -> 16.0 / 9.0;
        };
    }

    public static void nextPreset() { preset = (preset + 1) % PRESETS.length; save(); }

    public static void load() {
        if (!Files.exists(FILE)) return;
        try {
            Data d = GSON.fromJson(Files.readString(FILE), Data.class);
            if (d != null) {
                preset = Math.max(0, Math.min(PRESETS.length - 1, d.preset));
                customWidth = Math.max(0.25, Math.min(32.0, d.customWidth));
                customHeight = Math.max(0.25, Math.min(32.0, d.customHeight));
                enabled = d.enabled;
            }
        } catch (Exception ignored) { }
    }

    public static void save() {
        try {
            Files.createDirectories(FILE.getParent());
            Data d = new Data(); d.preset = preset; d.customWidth = customWidth; d.customHeight = customHeight; d.enabled = enabled;
            Files.writeString(FILE, GSON.toJson(d));
        } catch (IOException ignored) { }
    }

    private static final class Data {
        int preset = 3; double customWidth = 4.0; double customHeight = 3.0; boolean enabled = true;
    }
}
