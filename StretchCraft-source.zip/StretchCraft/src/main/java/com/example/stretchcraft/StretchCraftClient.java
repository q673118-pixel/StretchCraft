package com.example.stretchcraft;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.Minecraft;
import org.lwjgl.glfw.GLFW;

public final class StretchCraftClient implements ClientModInitializer {
    private static boolean menuKeyWasDown = false;

    @Override
    public void onInitializeClient() {
        StretchConfig.load();
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.getWindow() == null) return;
            boolean down = GLFW.glfwGetKey(client.getWindow().getWindow(), GLFW.GLFW_KEY_RIGHT_SHIFT) == GLFW.GLFW_PRESS
                    && GLFW.glfwGetKey(client.getWindow().getWindow(), GLFW.GLFW_KEY_R) == GLFW.GLFW_PRESS;
            if (down && !menuKeyWasDown && client.screen == null) {
                client.setScreen(new StretchScreen());
            }
            menuKeyWasDown = down;
        });
    }
}
