package com.example.stretchcraft.mixin;

import com.example.stretchcraft.StretchConfig;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GameRenderer;
import org.joml.Matrix4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(GameRenderer.class)
public abstract class GameRendererMixin {
    @Inject(method = "getProjectionMatrix", at = @At("RETURN"), cancellable = true)
    private void stretchcraft$changeProjection(float fov, CallbackInfoReturnable<Matrix4f> cir) {
        if (!StretchConfig.enabled) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.getWindow() == null || mc.getWindow().getHeight() <= 0) return;
        double actual = (double) mc.getWindow().getWidth() / (double) mc.getWindow().getHeight();
        double target = StretchConfig.targetAspect();
        float factor = (float) Math.max(0.1, Math.min(10.0, actual / target));
        Matrix4f stretched = new Matrix4f(cir.getReturnValue());
        stretched.m00(stretched.m00() * factor);
        cir.setReturnValue(stretched);
    }
}
